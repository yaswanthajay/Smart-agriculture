import React from 'react';

interface ProgressBarProps {
  value: number;
  max?: number;
  label?: string;
  showValue?: boolean;
  className?: string;
  variant?: 'primary' | 'secondary' | 'accent' | 'success' | 'warning' | 'danger';
  size?: 'sm' | 'md' | 'lg';
}

const ProgressBar: React.FC<ProgressBarProps> = ({
  value,
  max = 100,
  label,
  showValue = false,
  className = '',
  variant = 'primary',
  size = 'md'
}) => {
  const percentage = Math.min(Math.max(0, (value / max) * 100), 100);
  
  const variantClasses = {
    primary: 'bg-green-600',
    secondary: 'bg-blue-600',
    accent: 'bg-amber-500',
    success: 'bg-emerald-600',
    warning: 'bg-orange-500',
    danger: 'bg-red-600'
  };
  
  const sizeClasses = {
    sm: 'h-1',
    md: 'h-2',
    lg: 'h-3'
  };
  
  return (
    <div className={`w-full ${className}`}>
      {(label || showValue) && (
        <div className="flex justify-between mb-1 text-sm">
          {label && <span className="text-gray-700">{label}</span>}
          {showValue && <span className="text-gray-700">{value}/{max}</span>}
        </div>
      )}
      <div className={`w-full bg-gray-200 rounded-full overflow-hidden ${sizeClasses[size]}`}>
        <div
          className={`${variantClasses[variant]} transition-all duration-500 ease-out rounded-full ${sizeClasses[size]}`}
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
    </div>
  );
};

export default ProgressBar;