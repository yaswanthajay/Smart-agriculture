import React from 'react';
import { MarketItem } from '../../types';
import Card from '../ui/Card';
import Button from '../ui/Button';
import { ShoppingCart } from 'lucide-react';

interface MarketplaceItemCardProps {
  item: MarketItem;
}

const MarketplaceItemCard: React.FC<MarketplaceItemCardProps> = ({ item }) => {
  return (
    <Card className="h-full transition-all duration-300 hover:translate-y-[-5px]">
      <div className="flex flex-col h-full">
        <div className="relative h-48 w-full mb-4 overflow-hidden rounded-md">
          <img 
            src={item.image} 
            alt={item.name} 
            className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
          />
          <div className="absolute top-2 right-2 bg-white rounded-full px-2 py-1 text-xs font-medium text-gray-800">
            {item.category}
          </div>
        </div>
        
        <div className="flex-grow flex flex-col">
          <h3 className="text-lg font-semibold text-gray-800 mb-1">{item.name}</h3>
          
          <div className="flex items-center justify-between mb-3">
            <div className="text-xl font-bold text-green-700">${item.price.toFixed(2)}</div>
            <div className="text-sm text-gray-600">{item.quantity} {item.unit} available</div>
          </div>
          
          <div className="text-sm text-gray-600 mb-4">
            <p>Seller: {item.seller}</p>
            <p>Location: {item.location}</p>
          </div>
          
          <div className="mt-auto">
            <Button 
              variant="primary" 
              className="w-full"
              leftIcon={<ShoppingCart className="h-4 w-4" />}
            >
              Add to Cart
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default MarketplaceItemCard;