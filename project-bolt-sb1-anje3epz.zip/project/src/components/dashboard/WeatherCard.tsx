import React from 'react';
import { Weather } from '../../types';
import Card from '../ui/Card';
import { Sun, Cloud, CloudRain, CloudLightning } from 'lucide-react';

interface WeatherCardProps {
  weather: Weather;
  isToday?: boolean;
}

const WeatherCard: React.FC<WeatherCardProps> = ({ weather, isToday = false }) => {
  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    if (isToday) {
      return 'Today';
    }
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric'
    });
  };

  const getWeatherIcon = () => {
    switch (weather.condition) {
      case 'sunny':
        return <Sun className="h-8 w-8 text-amber-500" />;
      case 'cloudy':
        return <Cloud className="h-8 w-8 text-gray-400" />;
      case 'rainy':
        return <CloudRain className="h-8 w-8 text-blue-400" />;
      case 'stormy':
        return <CloudLightning className="h-8 w-8 text-purple-500" />;
      default:
        return <Sun className="h-8 w-8 text-amber-500" />;
    }
  };

  const getWeatherColor = () => {
    switch (weather.condition) {
      case 'sunny':
        return 'bg-amber-50';
      case 'cloudy':
        return 'bg-gray-50';
      case 'rainy':
        return 'bg-blue-50';
      case 'stormy':
        return 'bg-purple-50';
      default:
        return 'bg-amber-50';
    }
  };

  return (
    <Card className={`h-full transition-all duration-300 hover:shadow-lg ${getWeatherColor()}`}>
      <div className="flex flex-col items-center">
        <h3 className={`text-lg font-medium text-gray-800 ${isToday ? 'font-semibold' : ''}`}>
          {formatDate(weather.date)}
        </h3>
        <div className="mt-2 mb-2">{getWeatherIcon()}</div>
        <div className="text-2xl font-semibold text-gray-900">{weather.temperature}°F</div>
        <div className="mt-3 text-sm text-gray-600 capitalize">{weather.condition}</div>
        <div className="w-full mt-4 grid grid-cols-2 gap-2 text-xs text-gray-600">
          <div className="flex flex-col items-center">
            <span>Humidity</span>
            <span className="font-medium text-gray-800">{weather.humidity}%</span>
          </div>
          <div className="flex flex-col items-center">
            <span>Wind</span>
            <span className="font-medium text-gray-800">{weather.windSpeed} mph</span>
          </div>
          <div className="flex flex-col items-center">
            <span>Precip</span>
            <span className="font-medium text-gray-800">{weather.precipitation}" </span>
          </div>
          <div className="flex flex-col items-center">
            <span>Forecast</span>
            <span className="font-medium text-gray-800 capitalize">{weather.condition}</span>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default WeatherCard;