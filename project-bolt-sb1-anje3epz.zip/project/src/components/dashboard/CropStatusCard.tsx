import React from 'react';
import { Crop } from '../../types';
import Card from '../ui/Card';
import Badge from '../ui/Badge';
import ProgressBar from '../ui/ProgressBar';
import { Calendar, Leaf } from 'lucide-react';

interface CropStatusCardProps {
  crop: Crop;
}

const CropStatusCard: React.FC<CropStatusCardProps> = ({ crop }) => {
  const getStatusVariant = (status: string): 'primary' | 'secondary' | 'accent' | 'success' | 'warning' => {
    switch (status) {
      case 'planted': return 'secondary';
      case 'growing': return 'primary';
      case 'ready': return 'accent';
      case 'harvested': return 'success';
      default: return 'primary';
    }
  };

  const getHealthVariant = (health: number): 'success' | 'warning' | 'danger' => {
    if (health >= 80) return 'success';
    if (health >= 60) return 'warning';
    return 'danger';
  };

  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <Card 
      className="h-full transition-all duration-300 hover:translate-y-[-5px]"
      title={crop.name}
    >
      <div className="flex flex-col space-y-4">
        <div className="flex items-center justify-between">
          <Badge variant={getStatusVariant(crop.status)}>
            {crop.status.charAt(0).toUpperCase() + crop.status.slice(1)}
          </Badge>
          <span className="text-sm text-gray-600">{crop.type}</span>
        </div>
        
        <div className="mt-2">
          <p className="text-sm text-gray-600 mb-1">Crop Health</p>
          <ProgressBar 
            value={crop.health} 
            variant={getHealthVariant(crop.health)}
            showValue
          />
        </div>
        
        <div className="flex flex-col space-y-2 mt-2">
          <div className="flex items-center text-sm">
            <Leaf className="h-4 w-4 text-green-600 mr-2" />
            <span className="text-gray-700">Field: {crop.field}</span>
          </div>
          <div className="flex items-center text-sm">
            <Calendar className="h-4 w-4 text-blue-600 mr-2" />
            <span className="text-gray-700">Planted: {formatDate(crop.plantedDate)}</span>
          </div>
          <div className="flex items-center text-sm">
            <Calendar className="h-4 w-4 text-amber-600 mr-2" />
            <span className="text-gray-700">Harvest: {formatDate(crop.harvestDate)}</span>
          </div>
        </div>
        
        {crop.notes && (
          <div className="mt-2 p-2 bg-gray-50 rounded-md">
            <p className="text-sm text-gray-600">{crop.notes}</p>
          </div>
        )}
      </div>
    </Card>
  );
};

export default CropStatusCard;