import React from 'react';
import { Equipment } from '../../types';
import Card from '../ui/Card';
import Badge from '../ui/Badge';
import { Calendar, PenTool as Tool } from 'lucide-react';

interface EquipmentStatusCardProps {
  equipment: Equipment;
}

const EquipmentStatusCard: React.FC<EquipmentStatusCardProps> = ({ equipment }) => {
  const getStatusVariant = (status: string): 'primary' | 'secondary' | 'accent' | 'success' | 'warning' | 'danger' => {
    switch (status) {
      case 'available': return 'success';
      case 'in-use': return 'primary';
      case 'maintenance': return 'warning';
      default: return 'primary';
    }
  };

  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getDaysUntilNextMaintenance = (): number => {
    const today = new Date();
    const nextMaintenance = new Date(equipment.nextMaintenance);
    const diffTime = nextMaintenance.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  const daysUntilMaintenance = getDaysUntilNextMaintenance();
  const maintenanceAlert = daysUntilMaintenance <= 7;

  return (
    <Card 
      className="h-full transition-all duration-300 hover:translate-y-[-5px]"
      title={equipment.name}
    >
      <div className="flex flex-col space-y-4">
        <div className="flex items-center justify-between">
          <Badge variant={getStatusVariant(equipment.status)}>
            {equipment.status === 'in-use' ? 'In Use' : equipment.status.charAt(0).toUpperCase() + equipment.status.slice(1)}
          </Badge>
          <span className="text-sm text-gray-600">{equipment.type}</span>
        </div>
        
        <div className="flex flex-col space-y-2 mt-2">
          <div className="flex items-center text-sm">
            <Tool className="h-4 w-4 text-blue-600 mr-2" />
            <span className="text-gray-700">Last Maintenance: {formatDate(equipment.lastMaintenance)}</span>
          </div>
          <div className="flex items-center text-sm">
            <Calendar className={`h-4 w-4 ${maintenanceAlert ? 'text-red-600' : 'text-amber-600'} mr-2`} />
            <span className={`${maintenanceAlert ? 'text-red-700 font-medium' : 'text-gray-700'}`}>
              Next Maintenance: {formatDate(equipment.nextMaintenance)}
              {maintenanceAlert && <span className="ml-2 text-red-600">({daysUntilMaintenance} days)</span>}
            </span>
          </div>
        </div>
        
        {maintenanceAlert && (
          <div className={`mt-2 p-2 ${daysUntilMaintenance <= 3 ? 'bg-red-50 text-red-800' : 'bg-amber-50 text-amber-800'} rounded-md text-sm`}>
            {daysUntilMaintenance <= 0 
              ? 'Maintenance overdue!' 
              : `Maintenance scheduled in ${daysUntilMaintenance} days`}
          </div>
        )}
      </div>
    </Card>
  );
};

export default EquipmentStatusCard;