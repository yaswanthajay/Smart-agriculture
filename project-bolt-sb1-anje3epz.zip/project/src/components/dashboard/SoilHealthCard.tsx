import React from 'react';
import { SoilData } from '../../types';
import Card from '../ui/Card';
import ProgressBar from '../ui/ProgressBar';

interface SoilHealthCardProps {
  soilData: SoilData;
}

const SoilHealthCard: React.FC<SoilHealthCardProps> = ({ soilData }) => {
  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getPhColor = (ph: number): 'primary' | 'secondary' | 'accent' | 'success' | 'warning' | 'danger' => {
    if (ph >= 6.0 && ph <= 7.5) return 'success';
    if ((ph >= 5.5 && ph < 6.0) || (ph > 7.5 && ph <= 8.0)) return 'warning';
    return 'danger';
  };

  const getMoistureVariant = (moisture: number): 'primary' | 'secondary' | 'success' | 'warning' | 'danger' => {
    if (moisture >= 50 && moisture <= 75) return 'success';
    if ((moisture >= 40 && moisture < 50) || (moisture > 75 && moisture <= 85)) return 'warning';
    return 'danger';
  };

  return (
    <Card 
      className="h-full transition-all duration-300 hover:translate-y-[-5px]"
      title={soilData.fieldName}
    >
      <div className="flex flex-col space-y-4">
        <div className="text-sm text-gray-600">
          Last tested: {formatDate(soilData.lastTested)}
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-gray-600 mb-1">Moisture</p>
            <ProgressBar 
              value={soilData.moisture} 
              variant={getMoistureVariant(soilData.moisture)}
              showValue
            />
          </div>
          
          <div>
            <p className="text-sm text-gray-600 mb-1">pH Level</p>
            <div className="flex items-center">
              <span className={`text-lg font-medium ${
                getPhColor(soilData.ph) === 'success' ? 'text-green-600' : 
                getPhColor(soilData.ph) === 'warning' ? 'text-amber-600' : 'text-red-600'
              }`}>
                {soilData.ph.toFixed(1)}
              </span>
              <span className="text-sm text-gray-500 ml-1">/14</span>
            </div>
          </div>
        </div>
        
        <div className="mt-2">
          <p className="text-sm text-gray-600 mb-2">Nutrient Levels (ppm)</p>
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-green-50 p-2 rounded-md text-center">
              <p className="text-xs text-gray-600">Nitrogen</p>
              <p className="text-lg font-medium text-green-700">{soilData.nitrogen}</p>
            </div>
            <div className="bg-blue-50 p-2 rounded-md text-center">
              <p className="text-xs text-gray-600">Phosphorus</p>
              <p className="text-lg font-medium text-blue-700">{soilData.phosphorus}</p>
            </div>
            <div className="bg-amber-50 p-2 rounded-md text-center">
              <p className="text-xs text-gray-600">Potassium</p>
              <p className="text-lg font-medium text-amber-700">{soilData.potassium}</p>
            </div>
          </div>
        </div>
        
        <div className="mt-2">
          <p className="text-sm text-gray-600 mb-1">Organic Matter</p>
          <p className="text-lg font-medium text-gray-800">{soilData.organicMatter}%</p>
        </div>
      </div>
    </Card>
  );
};

export default SoilHealthCard;