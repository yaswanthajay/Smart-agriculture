import React from 'react';
import { FarmEvent } from '../../types';
import Badge from '../ui/Badge';
import { Calendar, Leaf, PenTool as Tool } from 'lucide-react';

interface FarmCalendarEventProps {
  event: FarmEvent;
}

const FarmCalendarEvent: React.FC<FarmCalendarEventProps> = ({ event }) => {
  const getEventTypeVariant = (type: string): 'primary' | 'secondary' | 'accent' | 'success' | 'warning' => {
    switch (type) {
      case 'planting': return 'primary';
      case 'fertilizing': return 'secondary';
      case 'pesticide': return 'warning';
      case 'irrigation': return 'secondary';
      case 'harvest': return 'accent';
      case 'maintenance': return 'warning';
      default: return 'primary';
    }
  };

  const getEventTypeIcon = (type: string) => {
    switch (type) {
      case 'planting':
      case 'fertilizing':
      case 'pesticide':
      case 'irrigation':
      case 'harvest':
        return <Leaf className="h-4 w-4 text-green-600" />;
      case 'maintenance':
        return <Tool className="h-4 w-4 text-blue-600" />;
      default:
        return <Calendar className="h-4 w-4 text-gray-600" />;
    }
  };

  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric'
    });
  };

  const isUpcoming = (): boolean => {
    const today = new Date();
    const eventDate = new Date(event.date);
    return eventDate >= today && !event.completed;
  };

  const isPast = (): boolean => {
    const today = new Date();
    const eventDate = new Date(event.date);
    return eventDate < today && !event.completed;
  };

  return (
    <div className={`p-4 rounded-lg border-l-4 mb-3 transition-all duration-300 ${
      event.completed 
        ? 'bg-gray-50 border-gray-300' 
        : isUpcoming()
          ? 'bg-white border-green-500 shadow-sm hover:shadow'
          : isPast() 
            ? 'bg-red-50 border-red-500'
            : 'bg-white border-blue-500 shadow-sm hover:shadow'
    }`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="flex-shrink-0">
            {getEventTypeIcon(event.type)}
          </div>
          <h3 className={`text-base font-medium ${
            event.completed 
              ? 'text-gray-500 line-through' 
              : isPast()
                ? 'text-red-700'
                : 'text-gray-800'
          }`}>
            {event.title}
          </h3>
        </div>
        <Badge variant={getEventTypeVariant(event.type)} className="capitalize">
          {event.type}
        </Badge>
      </div>
      
      <div className="mt-2 flex items-center text-sm text-gray-600">
        <Calendar className="h-4 w-4 mr-1" />
        <span>{formatDate(event.date)}</span>
        
        {event.field && (
          <>
            <span className="mx-2">•</span>
            <span>{event.field}</span>
          </>
        )}
        
        {event.crop && (
          <>
            <span className="mx-2">•</span>
            <span>{event.crop}</span>
          </>
        )}
      </div>
      
      {event.notes && (
        <div className="mt-2 text-sm text-gray-600">
          {event.notes}
        </div>
      )}
      
      {isPast() && !event.completed && (
        <div className="mt-2 text-sm text-red-600 font-medium">
          Overdue
        </div>
      )}
    </div>
  );
};

export default FarmCalendarEvent;