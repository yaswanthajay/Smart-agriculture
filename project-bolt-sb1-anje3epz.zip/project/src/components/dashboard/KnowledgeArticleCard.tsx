import React from 'react';
import { KnowledgeArticle } from '../../types';
import Card from '../ui/Card';
import Badge from '../ui/Badge';
import Button from '../ui/Button';
import { ArrowRight } from 'lucide-react';

interface KnowledgeArticleCardProps {
  article: KnowledgeArticle;
}

const KnowledgeArticleCard: React.FC<KnowledgeArticleCardProps> = ({ article }) => {
  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const truncateContent = (content: string, maxLength: number = 150): string => {
    if (content.length <= maxLength) return content;
    return content.slice(0, maxLength) + '...';
  };

  return (
    <Card className="h-full transition-all duration-300 hover:translate-y-[-5px]">
      <div className="flex flex-col h-full">
        <div className="relative h-40 w-full mb-4 overflow-hidden rounded-md">
          <img 
            src={article.imageUrl} 
            alt={article.title} 
            className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
          />
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-3">
            <Badge variant="secondary" className="bg-blue-500 text-white">{article.category}</Badge>
          </div>
        </div>
        
        <div className="flex-grow flex flex-col">
          <h3 className="text-lg font-semibold text-gray-800 mb-2 line-clamp-2">{article.title}</h3>
          
          <div className="text-sm text-gray-500 mb-3">
            By {article.author} • {formatDate(article.date)}
          </div>
          
          <p className="text-gray-600 mb-4 flex-grow">
            {truncateContent(article.content)}
          </p>
          
          <Button 
            variant="ghost" 
            className="mt-auto self-start text-green-700 hover:text-green-800 px-0"
            rightIcon={<ArrowRight className="h-4 w-4" />}
          >
            Read More
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default KnowledgeArticleCard;