import { Crop, Weather, Equipment, SoilData, MarketItem, KnowledgeArticle, FarmEvent } from '../types';

export const mockCrops: Crop[] = [
  {
    id: '1',
    name: 'Winter Wheat',
    type: 'Grain',
    plantedDate: '2025-02-15',
    harvestDate: '2025-07-20',
    field: 'North Field',
    status: 'growing',
    health: 85,
    notes: 'Growing well despite light rainfall'
  },
  {
    id: '2',
    name: 'Soybeans',
    type: 'Legume',
    plantedDate: '2025-04-10',
    harvestDate: '2025-09-30',
    field: 'East Field',
    status: 'planted',
    health: 92,
    notes: 'New high-yield variety'
  },
  {
    id: '3',
    name: 'Sweet Corn',
    type: 'Vegetable',
    plantedDate: '2025-05-01',
    harvestDate: '2025-08-15',
    field: 'South Field',
    status: 'growing',
    health: 78,
    notes: 'Some pest issues detected'
  },
  {
    id: '4',
    name: 'Alfalfa',
    type: 'Forage',
    plantedDate: '2024-09-15',
    harvestDate: '2025-05-30',
    field: 'West Field',
    status: 'ready',
    health: 95,
    notes: 'Ready for first cutting'
  }
];

export const mockWeather: Weather[] = [
  { date: '2025-05-15', condition: 'sunny', temperature: 75, humidity: 45, precipitation: 0, windSpeed: 5 },
  { date: '2025-05-16', condition: 'sunny', temperature: 78, humidity: 50, precipitation: 0, windSpeed: 7 },
  { date: '2025-05-17', condition: 'cloudy', temperature: 72, humidity: 65, precipitation: 0, windSpeed: 10 },
  { date: '2025-05-18', condition: 'rainy', temperature: 68, humidity: 80, precipitation: 0.75, windSpeed: 12 },
  { date: '2025-05-19', condition: 'rainy', temperature: 65, humidity: 85, precipitation: 1.2, windSpeed: 15 },
  { date: '2025-05-20', condition: 'cloudy', temperature: 70, humidity: 75, precipitation: 0.1, windSpeed: 8 },
  { date: '2025-05-21', condition: 'sunny', temperature: 76, humidity: 60, precipitation: 0, windSpeed: 6 }
];

export const mockEquipment: Equipment[] = [
  {
    id: '1',
    name: 'John Deere 8R Tractor',
    type: 'Tractor',
    status: 'available',
    lastMaintenance: '2025-03-15',
    nextMaintenance: '2025-09-15'
  },
  {
    id: '2',
    name: 'Case IH Combine Harvester',
    type: 'Harvester',
    status: 'maintenance',
    lastMaintenance: '2025-04-10',
    nextMaintenance: '2025-05-20'
  },
  {
    id: '3',
    name: 'Seed Drill',
    type: 'Planting',
    status: 'in-use',
    lastMaintenance: '2025-02-28',
    nextMaintenance: '2025-08-28'
  },
  {
    id: '4',
    name: 'Sprayer',
    type: 'Pest Control',
    status: 'available',
    lastMaintenance: '2025-04-25',
    nextMaintenance: '2025-07-25'
  }
];

export const mockSoilData: SoilData[] = [
  {
    fieldId: '1',
    fieldName: 'North Field',
    moisture: 65,
    ph: 6.8,
    nitrogen: 45,
    phosphorus: 35,
    potassium: 50,
    organicMatter: 3.2,
    lastTested: '2025-04-01'
  },
  {
    fieldId: '2',
    fieldName: 'East Field',
    moisture: 58,
    ph: 7.2,
    nitrogen: 38,
    phosphorus: 42,
    potassium: 45,
    organicMatter: 2.8,
    lastTested: '2025-04-02'
  },
  {
    fieldId: '3',
    fieldName: 'South Field',
    moisture: 72,
    ph: 6.5,
    nitrogen: 52,
    phosphorus: 30,
    potassium: 48,
    organicMatter: 3.5,
    lastTested: '2025-04-02'
  },
  {
    fieldId: '4',
    fieldName: 'West Field',
    moisture: 60,
    ph: 7.0,
    nitrogen: 42,
    phosphorus: 38,
    potassium: 44,
    organicMatter: 3.0,
    lastTested: '2025-04-03'
  }
];

export const mockMarketItems: MarketItem[] = [
  {
    id: '1',
    name: 'Organic Wheat Seeds',
    category: 'Seeds',
    price: 45.99,
    quantity: 50,
    unit: 'lb',
    seller: 'Green Valley Farm Supply',
    location: 'Springfield',
    image: 'https://images.pexels.com/photos/326082/pexels-photo-326082.jpeg'
  },
  {
    id: '2',
    name: 'Tractor Spare Parts',
    category: 'Equipment',
    price: 299.99,
    quantity: 5,
    unit: 'set',
    seller: 'Farm Mechanics Inc.',
    location: 'Riverside',
    image: 'https://images.pexels.com/photos/2220559/pexels-photo-2220559.jpeg'
  },
  {
    id: '3',
    name: 'Organic Fertilizer',
    category: 'Supplies',
    price: 29.99,
    quantity: 200,
    unit: 'lb',
    seller: 'Natural Grow Co.',
    location: 'Meadowville',
    image: 'https://images.pexels.com/photos/14310512/pexels-photo-14310512.jpeg'
  },
  {
    id: '4',
    name: 'Fresh Corn',
    category: 'Produce',
    price: 3.99,
    quantity: 500,
    unit: 'dozen',
    seller: 'Sunshine Acres',
    location: 'Clearwater',
    image: 'https://images.pexels.com/photos/547263/pexels-photo-547263.jpeg'
  }
];

export const mockKnowledgeArticles: KnowledgeArticle[] = [
  {
    id: '1',
    title: 'Sustainable Crop Rotation Practices',
    category: 'Farming Techniques',
    content: 'Crop rotation is a systematic approach to deciding which crop to plant where in your vegetable garden from one year to the next. The principle behind crop rotation is to avoid growing crops from the same family in the same soil for consecutive years...',
    author: 'Dr. Emma Johnson',
    date: '2025-03-15',
    imageUrl: 'https://images.pexels.com/photos/2165688/pexels-photo-2165688.jpeg'
  },
  {
    id: '2',
    title: 'Modern Irrigation Methods for Water Conservation',
    category: 'Water Management',
    content: 'Drip irrigation is a type of micro-irrigation system that has the potential to save water and nutrients by allowing water to drip slowly to the roots of plants, either from above the soil surface or buried below the surface...',
    author: 'Michael Chen, Agricultural Engineer',
    date: '2025-02-28',
    imageUrl: 'https://images.pexels.com/photos/2165677/pexels-photo-2165677.jpeg'
  },
  {
    id: '3',
    title: 'Soil Health Management for Organic Farms',
    category: 'Soil Science',
    content: 'Soil health is the foundation of productive farming. Healthy soil gives us clean air and water, bountiful crops and forests, productive grazing lands, diverse wildlife, and beautiful landscapes...',
    author: 'Dr. Thomas Garcia',
    date: '2025-04-05',
    imageUrl: 'https://images.pexels.com/photos/1342090/pexels-photo-1342090.jpeg'
  },
  {
    id: '4',
    title: 'Integrated Pest Management Strategies',
    category: 'Pest Control',
    content: 'Integrated Pest Management (IPM) is an effective and environmentally sensitive approach to pest management that relies on a combination of common-sense practices. IPM programs use current, comprehensive information on the life cycles of pests and their interaction with the environment...',
    author: 'Sarah Williams, Entomologist',
    date: '2025-03-22',
    imageUrl: 'https://images.pexels.com/photos/7728082/pexels-photo-7728082.jpeg'
  }
];

export const mockFarmEvents: FarmEvent[] = [
  {
    id: '1',
    title: 'Plant Soybeans',
    date: '2025-05-20',
    type: 'planting',
    field: 'East Field',
    crop: 'Soybeans',
    equipment: 'Seed Drill',
    completed: false,
    notes: 'Use new high-yield variety'
  },
  {
    id: '2',
    title: 'Fertilize Corn',
    date: '2025-05-22',
    type: 'fertilizing',
    field: 'South Field',
    crop: 'Sweet Corn',
    equipment: 'Sprayer',
    completed: false,
    notes: 'Apply organic nitrogen fertilizer'
  },
  {
    id: '3',
    title: 'Harvest Alfalfa',
    date: '2025-05-25',
    type: 'harvest',
    field: 'West Field',
    crop: 'Alfalfa',
    equipment: 'John Deere 8R Tractor',
    completed: false,
    notes: 'First cutting of the season'
  },
  {
    id: '4',
    title: 'Tractor Maintenance',
    date: '2025-05-28',
    type: 'maintenance',
    field: '',
    equipment: 'Case IH Combine Harvester',
    completed: false,
    notes: 'Scheduled maintenance and oil change'
  }
];