export interface Crop {
  id: string;
  name: string;
  type: string;
  plantedDate: string;
  harvestDate: string;
  field: string;
  status: 'planted' | 'growing' | 'ready' | 'harvested';
  health: number; // 0-100
  notes: string;
}

export interface Weather {
  date: string;
  condition: 'sunny' | 'cloudy' | 'rainy' | 'stormy';
  temperature: number;
  humidity: number;
  precipitation: number;
  windSpeed: number;
}

export interface Equipment {
  id: string;
  name: string;
  type: string;
  status: 'available' | 'in-use' | 'maintenance';
  lastMaintenance: string;
  nextMaintenance: string;
}

export interface SoilData {
  fieldId: string;
  fieldName: string;
  moisture: number; // 0-100
  ph: number; // 0-14
  nitrogen: number; // ppm
  phosphorus: number; // ppm
  potassium: number; // ppm
  organicMatter: number; // percentage
  lastTested: string;
}

export interface MarketItem {
  id: string;
  name: string;
  category: string;
  price: number;
  quantity: number;
  unit: string;
  seller: string;
  location: string;
  image: string;
}

export interface KnowledgeArticle {
  id: string;
  title: string;
  category: string;
  content: string;
  author: string;
  date: string;
  imageUrl: string;
}

export interface FarmEvent {
  id: string;
  title: string;
  date: string;
  type: 'planting' | 'fertilizing' | 'pesticide' | 'irrigation' | 'harvest' | 'maintenance';
  field: string;
  crop?: string;
  equipment?: string;
  completed: boolean;
  notes: string;
}