import React from 'react';
import { Tractor, Calendar, CloudRain, Linkedin as SeedingOutline, Shovel, ShoppingBag, BookOpen, LayoutDashboard } from 'lucide-react';
import { 
  mockCrops, mockWeather, mockEquipment, 
  mockSoilData, mockMarketItems, mockKnowledgeArticles,
  mockFarmEvents
} from '../data/mockData';
import CropStatusCard from '../components/dashboard/CropStatusCard';
import WeatherCard from '../components/dashboard/WeatherCard';
import EquipmentStatusCard from '../components/dashboard/EquipmentStatusCard';
import SoilHealthCard from '../components/dashboard/SoilHealthCard';
import MarketplaceItemCard from '../components/dashboard/MarketplaceItemCard';
import KnowledgeArticleCard from '../components/dashboard/KnowledgeArticleCard';
import FarmCalendarEvent from '../components/dashboard/FarmCalendarEvent';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';

const DashboardPage: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Farm Dashboard</h1>
        <p className="mt-2 text-lg text-gray-600">Welcome back! Here's an overview of your farm today.</p>
      </header>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white shadow-md">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-white/20 mr-4">
              <SeedingOutline className="h-8 w-8 text-white" strokeWidth={1.5} />
            </div>
            <div>
              <p className="text-white/80 text-sm">Active Crops</p>
              <p className="text-2xl font-bold">{mockCrops.length}</p>
            </div>
          </div>
        </Card>
        
        <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-md">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-white/20 mr-4">
              <Tractor className="h-8 w-8 text-white" strokeWidth={1.5} />
            </div>
            <div>
              <p className="text-white/80 text-sm">Equipment</p>
              <p className="text-2xl font-bold">{mockEquipment.length}</p>
            </div>
          </div>
        </Card>
        
        <Card className="bg-gradient-to-r from-amber-500 to-amber-600 text-white shadow-md">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-white/20 mr-4">
              <Shovel className="h-8 w-8 text-white" strokeWidth={1.5} />
            </div>
            <div>
              <p className="text-white/80 text-sm">Fields</p>
              <p className="text-2xl font-bold">{mockSoilData.length}</p>
            </div>
          </div>
        </Card>
        
        <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white shadow-md">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-white/20 mr-4">
              <Calendar className="h-8 w-8 text-white" strokeWidth={1.5} />
            </div>
            <div>
              <p className="text-white/80 text-sm">Upcoming Tasks</p>
              <p className="text-2xl font-bold">{mockFarmEvents.filter(e => !e.completed).length}</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Weather Forecast */}
      <section className="mb-10" id="weather">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <CloudRain className="h-6 w-6 text-blue-600 mr-2" />
            <h2 className="text-2xl font-bold text-gray-900">Weather Forecast</h2>
          </div>
          <Button variant="ghost" size="sm">View Details</Button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
          {mockWeather.map((weather, index) => (
            <WeatherCard 
              key={weather.date} 
              weather={weather} 
              isToday={index === 0} 
            />
          ))}
        </div>
      </section>

      {/* Crop Status */}
      <section className="mb-10" id="crops">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <SeedingOutline className="h-6 w-6 text-green-600 mr-2" />
            <h2 className="text-2xl font-bold text-gray-900">Crop Status</h2>
          </div>
          <Button variant="ghost" size="sm">View All Crops</Button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {mockCrops.map((crop) => (
            <CropStatusCard key={crop.id} crop={crop} />
          ))}
        </div>
      </section>

      {/* Equipment Status */}
      <section className="mb-10" id="equipment">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Tractor className="h-6 w-6 text-blue-600 mr-2" />
            <h2 className="text-2xl font-bold text-gray-900">Equipment Status</h2>
          </div>
          <Button variant="ghost" size="sm">View All Equipment</Button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {mockEquipment.map((equipment) => (
            <EquipmentStatusCard key={equipment.id} equipment={equipment} />
          ))}
        </div>
      </section>

      {/* Soil Health */}
      <section className="mb-10" id="soil">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Shovel className="h-6 w-6 text-amber-600 mr-2" />
            <h2 className="text-2xl font-bold text-gray-900">Soil Health</h2>
          </div>
          <Button variant="ghost" size="sm">View All Fields</Button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {mockSoilData.map((soil) => (
            <SoilHealthCard key={soil.fieldId} soilData={soil} />
          ))}
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-10">
        {/* Farm Calendar */}
        <div className="lg:col-span-1" id="calendar">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Calendar className="h-6 w-6 text-purple-600 mr-2" />
              <h2 className="text-2xl font-bold text-gray-900">Farm Calendar</h2>
            </div>
            <Button variant="ghost" size="sm">View All Events</Button>
          </div>
          <Card className="h-full">
            <div className="mb-4 flex justify-between items-center">
              <h3 className="text-lg font-medium text-gray-900">Upcoming Tasks</h3>
              <Button variant="primary" size="sm">Add Task</Button>
            </div>
            <div className="space-y-1">
              {mockFarmEvents.map((event) => (
                <FarmCalendarEvent key={event.id} event={event} />
              ))}
            </div>
          </Card>
        </div>

        {/* Marketplace & Knowledge Base */}
        <div className="lg:col-span-2">
          <div className="grid grid-cols-1 gap-8">
            {/* Marketplace */}
            <div id="marketplace">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center">
                  <ShoppingBag className="h-6 w-6 text-green-600 mr-2" />
                  <h2 className="text-2xl font-bold text-gray-900">Marketplace</h2>
                </div>
                <Button variant="ghost" size="sm">View Marketplace</Button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {mockMarketItems.slice(0, 2).map((item) => (
                  <MarketplaceItemCard key={item.id} item={item} />
                ))}
              </div>
            </div>

            {/* Knowledge Base */}
            <div id="knowledge">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center">
                  <BookOpen className="h-6 w-6 text-blue-600 mr-2" />
                  <h2 className="text-2xl font-bold text-gray-900">Knowledge Base</h2>
                </div>
                <Button variant="ghost" size="sm">Browse Articles</Button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {mockKnowledgeArticles.slice(0, 2).map((article) => (
                  <KnowledgeArticleCard key={article.id} article={article} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;